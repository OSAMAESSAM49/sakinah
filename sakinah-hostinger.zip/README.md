# سكينة · Sakinah — نسخة الرفع على Hostinger

## الإعدادات في hPanel (Websites → Add Website → Node.js Apps → Upload)

| الإعداد | القيمة |
|---|---|
| Framework | Other / Express |
| Node.js version | 20 أو 22 |
| Entry file | `server.js` |
| Install command | `npm install` |
| Build command | (فاضي) |
| Start command | `npm start` |

لا يحتاج أي متغيرات بيئة؛ السيرفر يقرأ `PORT` تلقائيًا من Hostinger.

## المحتوى

- `server.js` — السيرفر والـ API
- `lib/` — محرك البحث وتحميل البيانات
- `public/` — الواجهة والخطوط والصور
- `data/` — القرآن الكريم والكتب الستة (جاهزة، لا تحتاج تحميل)
