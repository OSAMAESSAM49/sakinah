// Sakinah — سكينة
// A calm search across the Holy Quran and the six books of hadith.
// Zero dependencies: run with `node server.js` (Node 18+).
const http = require('http');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { loadQuran, loadHadith, BOOKS } = require('./lib/data');
const { SearchEngine } = require('./lib/search');

const PORT = Number(process.env.PORT) || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
};

let engine = null;

function sendJson(req, res, status, body) {
  const json = JSON.stringify(body);
  const headers = { 'Content-Type': MIME['.json'], 'Cache-Control': 'no-store' };
  if (/\bgzip\b/.test(req.headers['accept-encoding'] || '') && json.length > 2048) {
    res.writeHead(status, { ...headers, 'Content-Encoding': 'gzip' });
    res.end(zlib.gzipSync(json));
  } else {
    res.writeHead(status, headers);
    res.end(json);
  }
}

function serveStatic(req, res, pathname) {
  const rel = pathname === '/' ? 'index.html' : decodeURIComponent(pathname).replace(/^\/+/, '');
  const file = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!file.startsWith(PUBLIC_DIR)) {
    res.writeHead(403);
    return res.end('Forbidden');
  }
  fs.stat(file, (err, stat) => {
    if (err || !stat.isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('Not found');
    }
    const ext = path.extname(file).toLowerCase();
    // Fonts never change; everything else is revalidated so replaced files (e.g. images) show up immediately.
    const longCache = ext === '.woff2';
    const lastModified = stat.mtime.toUTCString();
    const etag = `W/"${stat.size.toString(16)}-${stat.mtimeMs.toString(16)}"`;
    if (!longCache && (req.headers['if-none-match'] === etag || req.headers['if-modified-since'] === lastModified)) {
      res.writeHead(304, { ETag: etag, 'Last-Modified': lastModified, 'Cache-Control': 'no-cache' });
      return res.end();
    }
    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Cache-Control': longCache ? 'public, max-age=604800' : 'no-cache',
      'Last-Modified': lastModified,
      ETag: etag,
    });
    fs.createReadStream(file).pipe(res);
  });
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);

  if (url.pathname.startsWith('/api/')) {
    if (!engine) return sendJson(req, res, 503, { error: 'loading', message: 'جاري تجهيز البيانات، حاول بعد لحظات' });

    if (url.pathname === '/api/search') {
      const q = (url.searchParams.get('q') || '').trim().slice(0, 80);
      if (!q) return sendJson(req, res, 400, { error: 'empty', message: 'اكتب كلمة للبحث' });
      const type = ['all', 'quran', 'hadith'].includes(url.searchParams.get('type')) ? url.searchParams.get('type') : 'all';
      const book = BOOKS.some((b) => b.id === url.searchParams.get('book')) ? url.searchParams.get('book') : '';
      const offset = Math.max(0, parseInt(url.searchParams.get('offset'), 10) || 0);
      const limit = Math.min(60, Math.max(1, parseInt(url.searchParams.get('limit'), 10) || 24));
      return sendJson(req, res, 200, engine.search({ q, type, book, offset, limit }));
    }
    if (url.pathname === '/api/daily') return sendJson(req, res, 200, engine.random());
    if (url.pathname === '/api/books') return sendJson(req, res, 200, BOOKS);
    return sendJson(req, res, 404, { error: 'not_found' });
  }

  serveStatic(req, res, url.pathname);
});

server.listen(PORT, () => {
  console.log(`\n  سكينة · Sakinah  →  http://localhost:${PORT}\n`);
});

(async () => {
  const t = Date.now();
  console.log('  Loading Quran & hadith data ...');
  const [quran, hadith] = await Promise.all([loadQuran(), loadHadith()]);
  engine = new SearchEngine(quran, hadith, BOOKS);
  console.log(`  ✓ ${quran.length} ayah · ${hadith.length} hadith ready in ${((Date.now() - t) / 1000).toFixed(1)}s`);
})().catch((err) => {
  console.error('  ✗ Failed to load data:', err.message);
  process.exit(1);
});
